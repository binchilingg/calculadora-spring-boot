package br.com.calculadora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculadoraApplicationTests {
    @Test
    void contextoDaAplicacaoInicia() {
    }
}
